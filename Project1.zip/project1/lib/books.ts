export interface Book {
  id: string;
  title: string;
  author: string;
  authorFull: string;
  year: string;
  category: 'novel' | 'story' | 'poetry' | 'drama';
  categoryLabel: string;
  description: string;
  quote: string;
}

export const books: Book[] = [
  // Байрон
  {
    id: 'childe-harold',
    title: 'Паломництво Чайльд-Гарольда',
    author: 'Байрон',
    authorFull: 'Джордж Гордон Байрон',
    year: '1812–1818',
    category: 'poetry',
    categoryLabel: 'Поема',
    description: 'Поема, що принесла Байрону світову славу. Історія молодого аристократа, розчарованого в житті та який вирушив у мандрівку Європою в пошуках сенсу існування.',
    quote: 'Я прокинувся одного ранку і виявив себе знаменитим.',
  },
  {
    id: 'don-juan',
    title: 'Дон Жуан',
    author: 'Байрон',
    authorFull: 'Джордж Гордон Байрон',
    year: '1819–1824',
    category: 'poetry',
    categoryLabel: 'Поема',
    description: 'Незакінчена сатирична поема, одна з найвидатніших сатиричних епопей у світовій літературі. Байрон переосмислює легенду про Дон Жуана, роблячи його жертвою жіночих зваб.',
    quote: 'Правда завжди дивна — дивніша за вигадку.',
  },
  {
    id: 'manfred',
    title: 'Манфред',
    author: 'Байрон',
    authorFull: 'Джордж Гордон Байрон',
    year: '1817',
    category: 'drama',
    categoryLabel: 'Драматична поема',
    description: 'Філософська драма про графа Манфреда, який живе у самотності в Альпах, мучений таємною провиною та жагою до забуття.',
    quote: 'Горе тим, хто ніколи не навчився керувати собою!',
  },
  // Гете
  {
    id: 'faust',
    title: 'Фауст',
    author: 'Гете',
    authorFull: 'Йоганн Вольфганг фон Гете',
    year: '1808–1832',
    category: 'drama',
    categoryLabel: 'Трагедія',
    description: 'Величний твір німецької літератури про вченого Фауста, який укладає угоду з дияволом Мефістофелем в обмін на знання та молодість.',
    quote: 'Зупинися, мить! Ти чудова!',
  },
  // Шекспір
  {
    id: 'hamlet',
    title: 'Гамлет',
    author: 'Шекспір',
    authorFull: 'Вільям Шекспір',
    year: '1600–1601',
    category: 'drama',
    categoryLabel: 'Трагедія',
    description: 'Найвідоміша трагедія Шекспіра про данського принца, який прагне помститися за вбивство свого батька.',
    quote: 'Бути чи не бути — ось питання.',
  },
  // Набоков
  {
    id: 'lolita',
    title: 'Лоліта',
    author: 'Набоков',
    authorFull: 'Володимир Набоков',
    year: '1955',
    category: 'novel',
    categoryLabel: 'Роман',
    description: 'Суперечливий та блискучий роман про заборонену одержимість Гумберта Гумберта юною Долорес Гейз. Шедевр прози XX століття.',
    quote: 'Лоліта, світло мого життя, вогонь моїх чересл.',
  },
  // Оруелл
  {
    id: '1984',
    title: '1984',
    author: 'Оруелл',
    authorFull: 'Джордж Оруелл',
    year: '1949',
    category: 'novel',
    categoryLabel: 'Роман',
    description: 'Антиутопічний роман про тоталітарне суспільство, де Великий Брат стежить за кожним громадянином. Пророче попередження про небезпеки авторитаризму.',
    quote: 'Війна — це мир. Свобода — це рабство. Незнання — це сила.',
  },
  {
    id: 'animal-farm',
    title: 'Скотний двір',
    author: 'Оруелл',
    authorFull: 'Джордж Оруелл',
    year: '1945',
    category: 'story',
    categoryLabel: 'Повість-притча',
    description: 'Сатирична алегорія на тоталітаризм, де тварини на фермі повстають проти людей, але створюють ще жорстокішу диктатуру.',
    quote: 'Усі тварини рівні, але деякі тварини рівніші за інших.',
  },
  // Вольтер
  {
    id: 'philosophical-tales',
    title: 'Філософські повісті',
    author: 'Вольтер',
    authorFull: 'Вольтер (Франсуа-Марі Аруе)',
    year: '1747–1767',
    category: 'story',
    categoryLabel: 'Повісті',
    description: 'Збірка філософських творів, включаючи "Кандід", "Задіг" та "Простодушний". Гострі сатиричні твори про людські вади та суспільні забобони.',
    quote: 'Треба обробляти свій сад.',
  },
  // Гюго
  {
    id: 'notre-dame',
    title: 'Собор Паризької Богоматері',
    author: 'Гюго',
    authorFull: 'Віктор Гюго',
    year: '1831',
    category: 'novel',
    categoryLabel: 'Роман',
    description: 'Історичний роман про кохання горбаня Квазімодо до прекрасної циганки Есмеральди на тлі середньовічного Парижа та величного собору Нотр-Дам.',
    quote: 'Доля! Він кохав. Він, урод, був сліпим, горбатим, кульгавим. Вона ж, танцівниця, легка й тремтлива, як бджола.',
  },
  // Кафка
  {
    id: 'castle',
    title: 'Замок',
    author: 'Кафка',
    authorFull: 'Франц Кафка',
    year: '1926',
    category: 'novel',
    categoryLabel: 'Роман',
    description: 'Незавершений роман про землеміра К., який прибуває до села та намагається потрапити до таємничого Замку, що керує всім життям навколо.',
    quote: 'Я тут, щоб працювати, і в мене немає бажання бути тут даремно.',
  },
  // Гомер
  {
    id: 'iliad',
    title: 'Іліада',
    author: 'Гомер',
    authorFull: 'Гомер',
    year: 'VIII ст. до н.е.',
    category: 'poetry',
    categoryLabel: 'Епос',
    description: 'Давньогрецька епічна поема про події Троянської війни, гнів Ахілла та долі героїв. Один з найдавніших літературних творів західної цивілізації.',
    quote: 'Гнів оспівай, богине, Ахілла, сина Пелея.',
  },
];

export function getBookById(id: string): Book | undefined {
  return books.find(book => book.id === id);
}

export function getBooksByCategory(category: Book['category']): Book[] {
  return books.filter(book => book.category === category);
}

export function getBooksByAuthor(author: string): Book[] {
  return books.filter(book => book.author === author);
}

export const authors = [...new Set(books.map(book => book.author))];
