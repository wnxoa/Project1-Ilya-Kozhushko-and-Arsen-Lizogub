#!/usr/bin/env python3
"""
Генератор сайту європейської літератури
Створює HTML-файл з каталогом книг
"""

books = [
    # Байрон
    {
        "id": "childe-harold",
        "title": "Паломництво Чайльд-Гарольда",
        "author": "Байрон",
        "author_full": "Джордж Гордон Байрон",
        "year": "1812–1818",
        "category": "poetry",
        "category_label": "Поема",
        "description": "Ліро-епічна поема про мандри розчарованого молодого аристократа Європою. Твір, що приніс Байрону світову славу та став маніфестом романтизму.",
        "quote": "Я вивчив мови інших країн, і чужинці не були чужими для мене."
    },
    {
        "id": "don-juan",
        "title": "Дон Жуан",
        "author": "Байрон",
        "author_full": "Джордж Гордон Байрон",
        "year": "1819–1824",
        "category": "poetry",
        "category_label": "Поема",
        "description": "Сатирична поема-епопея, що переосмислює легенду про Дон Жуана. Незавершений шедевр, сповнений іронії, соціальної критики та філософських роздумів.",
        "quote": "Що таке слава? Щоб тебе впізнавали ті, кого ти не бажаєш знати."
    },
    {
        "id": "manfred",
        "title": "Манфред",
        "author": "Байрон",
        "author_full": "Джордж Гордон Байрон",
        "year": "1817",
        "category": "drama",
        "category_label": "Драма",
        "description": "Філософська драматична поема про самотнього мага, який шукає забуття від таємничої провини. Вершина байронічного героя в літературі.",
        "quote": "Горе тим, хто ніколи не навчився володіти собою."
    },
    # Гете
    {
        "id": "faust",
        "title": "Фауст",
        "author": "Гете",
        "author_full": "Йоганн Вольфганг фон Гете",
        "year": "1808–1832",
        "category": "drama",
        "category_label": "Драма",
        "description": "Трагедія про вченого, який продає душу дияволу заради знань і насолод. Філософський твір про сенс людського існування та межі пізнання.",
        "quote": "Зупинись, мить! Ти прекрасна!"
    },
    # Шекспір
    {
        "id": "hamlet",
        "title": "Гамлет",
        "author": "Шекспір",
        "author_full": "Вільям Шекспір",
        "year": "1600–1601",
        "category": "drama",
        "category_label": "Трагедія",
        "description": "Трагедія про данського принца, який прагне помститися за вбивство батька. Глибоке дослідження людської психіки, моралі та природи дії.",
        "quote": "Бути чи не бути — ось питання."
    },
    # Набоков
    {
        "id": "lolita",
        "title": "Лоліта",
        "author": "Набоков",
        "author_full": "Володимир Набоков",
        "year": "1955",
        "category": "novel",
        "category_label": "Роман",
        "description": "Контроверсійний роман про заборонену пристрасть Гумберта Гумберта. Визнаний шедевр стилю та один з найвпливовіших романів XX століття.",
        "quote": "Лоліта, світло мого життя, вогонь моїх чресел. Мій гріх, моя душа."
    },
    # Оруелл
    {
        "id": "1984",
        "title": "1984",
        "author": "Оруелл",
        "author_full": "Джордж Оруелл",
        "year": "1949",
        "category": "novel",
        "category_label": "Роман",
        "description": "Антиутопія про тоталітарне суспільство, де Великий Брат стежить за кожним. Пророчий твір про небезпеку абсолютної влади та маніпуляцій свідомістю.",
        "quote": "Війна — це мир. Свобода — це рабство. Незнання — це сила."
    },
    {
        "id": "animal-farm",
        "title": "Скотний двір",
        "author": "Оруелл",
        "author_full": "Джордж Оруелл",
        "year": "1945",
        "category": "story",
        "category_label": "Повість",
        "description": "Алегорична повість-притча про революцію тварин на фермі, що перетворюється на нову тиранію. Сатира на тоталітаризм та корупцію влади.",
        "quote": "Усі тварини рівні, але деякі тварини рівніші за інших."
    },
    # Вольтер
    {
        "id": "philosophical-tales",
        "title": "Філософські повісті",
        "author": "Вольтер",
        "author_full": "Вольтер (Франсуа-Марі Аруе)",
        "year": "1747–1767",
        "category": "story",
        "category_label": "Повісті",
        "description": "Збірка філософських творів, включаючи \"Кандід\", \"Задіг\" та \"Простодушний\". Гострі сатиричні твори про людські вади та суспільні забобони.",
        "quote": "Треба обробляти свій сад."
    },
    # Гюго
    {
        "id": "notre-dame",
        "title": "Собор Паризької Богоматері",
        "author": "Гюго",
        "author_full": "Віктор Гюго",
        "year": "1831",
        "category": "novel",
        "category_label": "Роман",
        "description": "Історичний роман про кохання горбаня Квазімодо до прекрасної циганки Есмеральди на тлі середньовічного Парижа та величного собору Нотр-Дам.",
        "quote": "Доля! Він кохав. Він, урод, був сліпим, горбатим, кульгавим."
    },
    # Кафка
    {
        "id": "castle",
        "title": "Замок",
        "author": "Кафка",
        "author_full": "Франц Кафка",
        "year": "1926",
        "category": "novel",
        "category_label": "Роман",
        "description": "Незавершений роман про землеміра К., який прибуває до села та намагається потрапити до таємничого Замку, що керує всім життям навколо.",
        "quote": "Я тут, щоб працювати, і в мене немає бажання бути тут даремно."
    },
    # Гомер
    {
        "id": "iliad",
        "title": "Іліада",
        "author": "Гомер",
        "author_full": "Гомер",
        "year": "VIII ст. до н.е.",
        "category": "poetry",
        "category_label": "Епос",
        "description": "Давньогрецька епічна поема про події Троянської війни, гнів Ахілла та долі героїв. Один з найдавніших літературних творів західної цивілізації.",
        "quote": "Гнів оспівай, богине, Ахілла, сина Пелея."
    },
]

def generate_book_card(book: dict) -> str:
    return f'''
    <article class="book-card" onclick="showBook('{book["id"]}')" data-category="{book["category"]}">
        <div class="book-spine"></div>
        <div class="book-content">
            <span class="book-category">{book["category_label"]}</span>
            <h3 class="book-title">{book["title"]}</h3>
            <p class="book-author">{book["author"]}, {book["year"]}</p>
            <p class="book-description">{book["description"][:120]}...</p>
        </div>
    </article>
    '''

def generate_book_detail(book: dict) -> str:
    return f'''
    <div id="book-{book["id"]}" class="book-detail hidden">
        <button class="back-btn" onclick="showCatalog()">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Назад до каталогу
        </button>
        
        <div class="book-hero">
            <div class="book-hero-content">
                <span class="book-category">{book["category_label"]}</span>
                <h1 class="book-hero-title">{book["title"]}</h1>
                <p class="book-hero-author">{book["author_full"]} · {book["year"]}</p>
            </div>
        </div>
        
        <div class="book-body">
            <blockquote class="book-quote">
                <p>«{book["quote"]}»</p>
            </blockquote>
            
            <section class="book-section">
                <h2>Про твір</h2>
                <p>{book["description"]}</p>
            </section>
            
            <section class="book-section">
                <h2>Про автора</h2>
                <p>{book["author_full"]} — видатний представник європейської літератури, чиї твори вплинули на розвиток світової культури.</p>
            </section>
        </div>
    </div>
    '''

def generate_html() -> str:
    novels = [b for b in books if b["category"] == "novel"]
    stories = [b for b in books if b["category"] == "story"]
    drama = [b for b in books if b["category"] == "drama"]
    poetry = [b for b in books if b["category"] == "poetry"]
    
    authors = len(set(b["author"] for b in books))
    
    html = f'''<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Європейська Література</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        :root {{
            --bg: #f7f5f0;
            --fg: #1a1814;
            --card: #fdfcfa;
            --primary: #4a3f33;
            --accent: #8b4513;
            --muted: #4d473e;
            --border: #e0dcd4;
        }}
        
        body {{
            font-family: 'Cormorant Garamond', Georgia, serif;
            background: var(--bg);
            color: var(--fg);
            line-height: 1.6;
            font-size: 18px;
            font-weight: 500;
        }}
        
        /* Header */
        header {{
            background: var(--card);
            border-bottom: 1px solid var(--border);
            padding: 1rem 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
        }}
        
        .header-content {{
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }}
        
        .logo {{
            font-family: 'Playfair Display', serif;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary);
            text-decoration: none;
            cursor: pointer;
        }}
        
        nav {{
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
        }}
        
        nav a {{
            color: var(--muted);
            text-decoration: none;
            font-size: 1rem;
            transition: color 0.2s;
        }}
        
        nav a:hover {{
            color: var(--primary);
        }}
        
        /* Main Content */
        main {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }}
        
        /* Hero Section */
        .hero {{
            text-align: center;
            padding: 4rem 1rem;
            border-bottom: 1px solid var(--border);
            margin-bottom: 3rem;
        }}
        
        .hero h1 {{
            font-family: 'Playfair Display', serif;
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--fg);
        }}
        
        .hero p {{
            font-size: 1.35rem;
            color: var(--fg);
            max-width: 600px;
            margin: 0 auto 2rem;
            font-weight: 500;
        }}
        
        .stats {{
            display: flex;
            justify-content: center;
            gap: 3rem;
            flex-wrap: wrap;
        }}
        
        .stat {{
            text-align: center;
        }}
        
        .stat-value {{
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary);
        }}
        
        .stat-label {{
            font-size: 0.875rem;
            color: var(--muted);
        }}
        
        /* Sections */
        .section {{
            margin-bottom: 4rem;
        }}
        
        .section-header {{
            margin-bottom: 2rem;
        }}
        
        .section-header h2 {{
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }}
        
        .section-header p {{
            color: var(--muted);
            font-size: 0.9rem;
        }}
        
        /* Book Grid */
        .book-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }}
        
        /* Book Card */
        .book-card {{
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1.5rem;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            position: relative;
            overflow: hidden;
        }}
        
        .book-card:hover {{
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }}
        
        .book-spine {{
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: var(--accent);
        }}
        
        .book-content {{
            padding-left: 1rem;
        }}
        
        .book-category {{
            display: inline-block;
            background: var(--bg);
            color: var(--muted);
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            border-radius: 4px;
            margin-bottom: 0.75rem;
        }}
        
        .book-title {{
            font-family: 'Playfair Display', serif;
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--fg);
        }}
        
        .book-author {{
            font-size: 1rem;
            color: var(--primary);
            margin-bottom: 0.75rem;
            font-weight: 600;
        }}
        
        .book-description {{
            font-size: 1rem;
            color: var(--fg);
            line-height: 1.6;
            font-weight: 500;
        }}
        
        /* Book Detail Page */
        .book-detail {{
            animation: fadeIn 0.3s ease;
        }}
        
        .book-detail.hidden {{
            display: none;
        }}
        
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(10px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        
        .back-btn {{
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: none;
            border: 1px solid var(--border);
            color: var(--muted);
            font-family: inherit;
            font-size: 1rem;
            padding: 0.75rem 1.25rem;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            margin-bottom: 2rem;
        }}
        
        .back-btn:hover {{
            background: var(--card);
            color: var(--fg);
        }}
        
        .book-hero {{
            background: linear-gradient(135deg, var(--primary) 0%, #4a3f33 100%);
            border-radius: 12px;
            padding: 3rem 2rem;
            margin-bottom: 2rem;
        }}
        
        .book-hero-content {{
            max-width: 600px;
        }}
        
        .book-hero .book-category {{
            background: rgba(255,255,255,0.2);
            color: rgba(255,255,255,0.9);
        }}
        
        .book-hero-title {{
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
            margin: 1rem 0;
        }}
        
        .book-hero-author {{
            color: rgba(255,255,255,0.8);
            font-size: 1.125rem;
        }}
        
        .book-body {{
            max-width: 800px;
        }}
        
        .book-quote {{
            background: var(--card);
            border-left: 4px solid var(--accent);
            padding: 2rem;
            margin-bottom: 2rem;
            border-radius: 0 8px 8px 0;
        }}
        
        .book-quote p {{
            font-family: 'Playfair Display', serif;
            font-size: 1.375rem;
            font-style: italic;
            color: var(--fg);
            line-height: 1.6;
        }}
        
        .book-section {{
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 2rem;
            margin-bottom: 1.5rem;
        }}
        
        .book-section h2 {{
            font-family: 'Playfair Display', serif;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--fg);
        }}
        
        .book-section p {{
            font-size: 1.2rem;
            color: var(--fg);
            line-height: 1.8;
            font-weight: 500;
        }}
        
        /* Footer */
        footer {{
            text-align: center;
            padding: 3rem 2rem;
            border-top: 1px solid var(--border);
            margin-top: 4rem;
        }}
        
        footer p {{
            color: var(--muted);
            font-size: 0.9rem;
        }}
        
        /* Catalog container */
        #catalog {{
            display: block;
        }}
        
        #catalog.hidden {{
            display: none;
        }}
        
        /* Responsive */
        @media (max-width: 768px) {{
            .hero h1 {{
                font-size: 2rem;
            }}
            
            .book-hero-title {{
                font-size: 1.75rem;
            }}
            
            .stats {{
                gap: 2rem;
            }}
            
            nav {{
                gap: 1rem;
            }}
        }}
    </style>
</head>
<body>
    <header>
        <div class="header-content">
            <span class="logo" onclick="showCatalog()">Європейська Література</span>
            <nav>
                <a href="#novels" onclick="showCatalog()">Романи</a>
                <a href="#stories" onclick="showCatalog()">Повісті</a>
                <a href="#drama" onclick="showCatalog()">Драматургія</a>
                <a href="#poetry" onclick="showCatalog()">Поезія</a>
            </nav>
        </div>
    </header>
    
    <main>
        <!-- Catalog View -->
        <div id="catalog">
            <section class="hero">
                <h1>Європейська Література</h1>
                <p>Колекція великих творів, що сформували європейську культурну спадщину</p>
                <div class="stats">
                    <div class="stat">
                        <div class="stat-value">{len(books)}</div>
                        <div class="stat-label">творів</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value">{authors}</div>
                        <div class="stat-label">авторів</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value">VIII ст. до н.е.</div>
                        <div class="stat-label">найдавніший твір</div>
                    </div>
                </div>
            </section>
            
            <section class="section" id="novels">
                <div class="section-header">
                    <h2>Романи</h2>
                    <p>Великі романи європейської прози</p>
                </div>
                <div class="book-grid">
                    {"".join(generate_book_card(b) for b in novels)}
                </div>
            </section>
            
            <section class="section" id="stories">
                <div class="section-header">
                    <h2>Повісті</h2>
                    <p>Філософські та сатиричні повісті</p>
                </div>
                <div class="book-grid">
                    {"".join(generate_book_card(b) for b in stories)}
                </div>
            </section>
            
            <section class="section" id="drama">
                <div class="section-header">
                    <h2>Драматургія</h2>
                    <p>Трагедії та драматичні поеми</p>
                </div>
                <div class="book-grid">
                    {"".join(generate_book_card(b) for b in drama)}
                </div>
            </section>
            
            <section class="section" id="poetry">
                <div class="section-header">
                    <h2>Поезія та Епос</h2>
                    <p>Поеми та епічні твори</p>
                </div>
                <div class="book-grid">
                    {"".join(generate_book_card(b) for b in poetry)}
                </div>
            </section>
        </div>
        
        <!-- Book Detail Views -->
        {"".join(generate_book_detail(b) for b in books)}
    </main>
    
    <footer>
        <p>Європейська Література — Колекція великих творів</p>
    </footer>
    
    <script>
        function showBook(bookId) {{
            document.getElementById('catalog').classList.add('hidden');
            document.querySelectorAll('.book-detail').forEach(el => el.classList.add('hidden'));
            document.getElementById('book-' + bookId).classList.remove('hidden');
            window.scrollTo(0, 0);
        }}
        
        function showCatalog() {{
            document.querySelectorAll('.book-detail').forEach(el => el.classList.add('hidden'));
            document.getElementById('catalog').classList.remove('hidden');
        }}
    </script>
</body>
</html>
'''
    return html

if __name__ == "__main__":
    html_content = generate_html()
    
    output_path = "european_literature.html"
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    
    print(f"HTML-файл створено: {output_path}")
    print(f"Кількість книг: {len(books)}")
    print(f"Кількість авторів: {len(set(b['author'] for b in books))}")
