import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Header } from '@/components/header';
import { BookCard } from '@/components/book-card';
import { getBookById, getBooksByAuthor, books } from '@/lib/books';
import { ArrowLeft, Quote, User, Calendar, BookOpen } from 'lucide-react';
import { Metadata } from 'next';

interface BookPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: BookPageProps): Promise<Metadata> {
  const { id } = await params;
  const book = getBookById(id);
  
  if (!book) {
    return { title: 'Книгу не знайдено' };
  }

  return {
    title: `${book.title} — ${book.authorFull}`,
    description: book.description,
  };
}

export async function generateStaticParams() {
  return books.map((book) => ({
    id: book.id,
  }));
}

export default async function BookPage({ params }: BookPageProps) {
  const { id } = await params;
  const book = getBookById(id);

  if (!book) {
    notFound();
  }

  const otherBooksByAuthor = getBooksByAuthor(book.author).filter(b => b.id !== book.id);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <Link 
            href="/" 
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm"
          >
            <ArrowLeft className="h-4 w-4" />
            Повернутися до каталогу
          </Link>
        </div>
      </div>

      {/* Book Details */}
      <article className="py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Category Badge */}
            <span className="inline-block text-xs font-medium text-accent uppercase tracking-wider mb-4 bg-accent/10 px-3 py-1 rounded-full">
              {book.categoryLabel}
            </span>

            {/* Title */}
            <h1 className="font-serif text-3xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight text-balance">
              {book.title}
            </h1>

            {/* Author Info */}
            <div className="flex flex-wrap items-center gap-6 mb-10 text-muted-foreground">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span>{book.authorFull}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{book.year}</span>
              </div>
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span>{book.categoryLabel}</span>
              </div>
            </div>

            {/* Quote */}
            <blockquote className="relative bg-secondary/70 border-l-4 border-primary p-6 md:p-8 rounded-r-lg mb-10">
              <Quote className="absolute top-4 right-4 h-8 w-8 text-primary/20" />
              <p className="font-serif text-lg md:text-xl text-foreground italic leading-relaxed">
                {'"'}{book.quote}{'"'}
              </p>
            </blockquote>

            {/* Description */}
            <div className="prose prose-lg max-w-none">
              <h2 className="font-serif text-2xl font-bold text-foreground mb-4">Про твір</h2>
              <p className="text-foreground/80 leading-relaxed text-lg">
                {book.description}
              </p>
            </div>

            {/* Decorative Divider */}
            <div className="flex items-center justify-center my-12">
              <div className="h-px bg-border flex-1" />
              <div className="px-4">
                <BookOpen className="h-6 w-6 text-primary/40" />
              </div>
              <div className="h-px bg-border flex-1" />
            </div>

            {/* Author Section */}
            <div className="bg-card border border-border rounded-lg p-6 md:p-8">
              <h2 className="font-serif text-xl font-bold text-foreground mb-4">Про автора</h2>
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <User className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-semibold text-foreground mb-2">{book.authorFull}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {getAuthorBio(book.author)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </article>

      {/* Other Books by Author */}
      {otherBooksByAuthor.length > 0 && (
        <section className="py-12 md:py-20 bg-secondary/50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground mb-8">
                Інші твори автора
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {otherBooksByAuthor.map((otherBook) => (
                  <BookCard key={otherBook.id} book={otherBook} />
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-card">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <BookOpen className="h-5 w-5 text-primary" />
            <span className="font-serif text-lg font-semibold text-foreground">Європейська Література</span>
          </div>
          <p className="text-muted-foreground text-sm max-w-md mx-auto">
            Колекція великих творів європейської літератури XIX століття
          </p>
        </div>
      </footer>
    </div>
  );
}

function getAuthorBio(author: string): string {
  const bios: Record<string, string> = {
    'Байрон': 'Джордж Гордон Байрон (1788–1824) — англійський поет-романтик, який справив величезний вплив на світову літературу. Його твори відрізняються пристрасністю, бунтарським духом та глибоким ліризмом. Байрон став символом романтичного героя — бунтівника, що кидає виклик суспільству.',
  };
  return bios[author] || '';
}
