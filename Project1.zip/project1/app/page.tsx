import { Header } from '@/components/header';
import { BookCard } from '@/components/book-card';
import { books, getBooksByCategory, authors } from '@/lib/books';
import { BookOpen, Feather, Theater, BookText } from 'lucide-react';

export default function HomePage() {
  const novels = getBooksByCategory('novel');
  const stories = getBooksByCategory('story');
  const poetry = getBooksByCategory('poetry');
  const drama = getBooksByCategory('drama');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-secondary via-background to-background" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight text-balance">
              Європейська класична література
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Відкрийте для себе безсмертні шедеври європейської літератури
            </p>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 gap-8 max-w-md mx-auto mt-16">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-serif font-bold text-primary">{books.length}</div>
              <div className="text-sm text-muted-foreground mt-1">Творів</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-serif font-bold text-primary">{authors.length}</div>
              <div className="text-sm text-muted-foreground mt-1">Авторів</div>
            </div>
          </div>
        </div>
      </section>

      {/* Novels Section */}
      {novels.length > 0 && (
        <section id="novels" className="py-16 md:py-24 bg-card/50">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <BookOpen className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">Романи</h2>
                <p className="text-muted-foreground text-sm">Великі романи європейської літератури</p>
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {novels.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Stories Section */}
      {stories.length > 0 && (
        <section id="stories" className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <BookText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">Повісті</h2>
                <p className="text-muted-foreground text-sm">Філософські та сатиричні повісті</p>
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {stories.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Drama Section */}
      {drama.length > 0 && (
        <section id="drama" className="py-16 md:py-24 bg-card/50">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Theater className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">Драматургія</h2>
                <p className="text-muted-foreground text-sm">Трагедії та драматичні поеми</p>
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {drama.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Poetry Section */}
      {poetry.length > 0 && (
        <section id="poetry" className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Feather className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">Поезія та Епос</h2>
                <p className="text-muted-foreground text-sm">Поеми та епічні твори європейської літератури</p>
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {poetry.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-card">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <BookOpen className="h-5 w-5 text-primary" />
            <span className="font-serif text-lg font-semibold text-foreground">Європейська Література</span>
          </div>
          <p className="text-muted-foreground text-sm max-w-md mx-auto">
            Колекція великих творів європейської літератури
          </p>
        </div>
      </footer>
    </div>
  );
}
