'use client';

import Link from 'next/link';
import { BookOpen } from 'lucide-react';

export function Header() {
  return (
    <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 group">
          <BookOpen className="h-7 w-7 text-primary transition-transform group-hover:scale-110" />
          <span className="font-serif text-xl font-semibold text-foreground tracking-tight">
            Європейська Література
          </span>
        </Link>
        <nav className="hidden md:flex items-center gap-8">
          <Link 
            href="/#novels" 
            className="text-muted-foreground hover:text-foreground transition-colors text-sm font-medium"
          >
            Романи
          </Link>
          <Link 
            href="/#stories" 
            className="text-muted-foreground hover:text-foreground transition-colors text-sm font-medium"
          >
            Повісті
          </Link>
          <Link 
            href="/#drama" 
            className="text-muted-foreground hover:text-foreground transition-colors text-sm font-medium"
          >
            Драматургія
          </Link>
          <Link 
            href="/#poetry" 
            className="text-muted-foreground hover:text-foreground transition-colors text-sm font-medium"
          >
            Поезія
          </Link>
        </nav>
      </div>
    </header>
  );
}
