import Link from 'next/link';
import { Book } from '@/lib/books';
import { ArrowRight } from 'lucide-react';

interface BookCardProps {
  book: Book;
}

export function BookCard({ book }: BookCardProps) {
  return (
    <Link 
      href={`/book/${book.id}`}
      className="group block bg-card border border-border rounded-lg p-6 hover:shadow-lg hover:border-primary/30 transition-all duration-300"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <span className="inline-block text-xs font-medium text-accent uppercase tracking-wider mb-2">
            {book.categoryLabel}
          </span>
          <h3 className="font-serif text-xl font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">
            {book.title}
          </h3>
          <p className="text-muted-foreground text-sm mb-3">
            {book.authorFull}, {book.year}
          </p>
          <p className="text-foreground/80 text-sm leading-relaxed line-clamp-2">
            {book.description}
          </p>
        </div>
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-secondary flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
          <ArrowRight className="h-4 w-4" />
        </div>
      </div>
    </Link>
  );
}
